const express = require('express')
const router = express.Router()
const { register } = require("../Auth/auth")
router.route('/register').post(register)
module.exports = router
















































































// const { User, org } = require('../models/user_auth');
// router.post('/register', (req, res) => {
//     const { firstName, lastName, email, password, phone } = req.body;
//     return User.create({
//         firstName, lastName, email, password, phone,
//     })
// }).then(user => {
//     org.create({
//         name: `${firstName}'s Organization`,
//         description: 'A random description for the organization',
//         userId: user.id

//     });
// }).then(() => {
//     res.status(201).json({ message: 'User registered successfully' })
//         .catch(error => {
//             console.error('error');
//             res.status(400).json({ error: 'Registration Unsuccessful' })
//         });
// });
// module.exports = router
// const { org } = require('../models');
// router.post('/register', (req, res) => {
//     const { name, description} = req.body;
//     return User.create({
//         name, description
//     });
// }).then((user) => {
//     res.status(201).json({
//         message: 'Registration Successful', user
//     });
// }).catch((error) => {
//     console.error('error');
//     res.status(400).json({ error: 'Registration Unsuccessful' })
// })