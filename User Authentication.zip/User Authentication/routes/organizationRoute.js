// const express = require('express')
// const router = express.Router();
// const { org } = require('../models');
// router.post('/register', (req, res) => {
//     const { name, description} = req.body;
//     return User.create({
//         name, description
//     });
// }).then((user) => {
//     res.status(201).json({
//         message: 'Registration Successful', user
//     });
// }).catch((error) => {
//     console.error('error');
//     res.status(400).json({ error: 'Registration Unsuccessful' })
// })