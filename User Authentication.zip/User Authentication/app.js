const express = require('express');
const app = express();
const userRoute = require('./routes/userRoutes');
// const organizationRoutes = require('./routes/organizationRoute');
const nsequelize = require('./config/config.json');

//Middleware
app.use(express.json());
// Routes
app.use('/api', require("./routes/userRoutes"))
// app.use('/api', organizationRoutes)


// nsequelize.sync().then(() => {
    let port = 3000
    app.listen(port, () => {
        console.log('server running on port ' + port);
    });
// }).catch(err =>
//     console.error('Dabase connection failed: ', err));
// process.on("unhandledRejection", err => {
//     console.log(`An error occured: ${err.message}`)
// })