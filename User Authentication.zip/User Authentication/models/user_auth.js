const Sequelize = require('sequelize');
const sequelize = new Sequelize('user_authentication', 'root', 'ADEADE2004**ade', {
    dialect: 'mysql'
});
const { DataTypes, Op } = Sequelize;
const bcrypt = require('bcryptjs');

module.exports = () => {

    const User = sequelize.define('auth_user', {
        userId: {
            type: DataTypes.INTEGER,
            unique: true,
            primaryKey: true,
            autoIncrement: true
        },
        firstName: {
            type: DataTypes.STRING,
            allowNull: false
        },
        lastName: {
            type: DataTypes.STRING,
            allowNull: false
        },
        email: {
            type: DataTypes.STRING,
            unique: true,
            allowNull: false
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false,
            set(value) {
                const salt = bcrypt.genSaltSync(12)
                const hash = bcrypt.hashSync(value, salt)
                this.setDataValue('password', hash)
            }
        },
        phone: {
            type: DataTypes.STRING
        }
    }, {
        freezeTableName: true
    });
    // const Nuser = Sequelize.Model("user_auth",User)
    // User.sync({ alter: true }).then((data) => {
    //     console.log('Table and model synced successfully')
    // }).catch((err) => {
    //     console.log('Error syncing the table and model')
    // });
    return {User}
}