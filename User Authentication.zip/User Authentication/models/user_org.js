const Sequelize = require('sequelize');
const sequelize = new Sequelize('user_authentication', 'root', 'ADEADE2004**ade', {
    dialect: 'mysql'
});
const { DataTypes, Op } = Sequelize;

const User = sequelize.define('auth_user', {
    userId: {
        type: DataTypes.INTEGER,
        unique: true,
        primaryKey: true,
        autoIncrement: true
    },
    firstName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    lastName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    email: {
        type: DataTypes.STRING,
        unique: true,
        allowNull: false
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false,
        set(value) {
            const salt = bcrypt.genSaltSync(12)
            const hash = bcrypt.hashSync(value, salt)
            this.setDataValue('password', hash)
        }
    },
    phone: {
        type: DataTypes.STRING
    }
}, {
    freezeTableName: true
});

const org = sequelize.define('organisation', {
    orgId: {
        type: DataTypes.INTEGER,
        unique: true,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    description: {
        type: DataTypes.STRING,
    }
}, {
    freezeTableName: true
})

const user_Org = sequelize.define('userOrg', {
    userOrgId: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    }
}, {
    freezeTableName: true,
    timestamps: false
})
user_Org.sync({ alter: true }).then((data) => {
    console.log('Table and model synced successfully')
}).catch((err) => {
    console.log('Error syncing the table and model')
}); 
User.belongsToMany(org, {
    through: user_Org,
    foreignKey: 'userId'
})
org.belongsToMany(User, {
    through: user_Org,
    foreignKey: 'orgId'
})
// return { User, org, user_Org }


user_Org.sync({ alter: true }).then((data) => {
    console.log('Table and model synced successfully')
}).catch((err) => {
    console.log('Error syncing the table and model')
}); 