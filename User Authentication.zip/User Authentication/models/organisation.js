const Sequelize = require('sequelize');
const sequelize = new Sequelize('user_authentication', 'root', 'ADEADE2004**ade', {
    dialect: 'mysql'
});
const { DataTypes, Op } = Sequelize;

const org = sequelize.define('organisation', {
    orgId: {
        type: DataTypes.INTEGER,
        unique: true,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    description: {
        type: DataTypes.STRING,
    }
}, {
    freezeTableName: true
})
// org.sync({ alter: true }).then((data) => {
//     console.log('Table and model synced successfully')
// }).catch((err) => {
//     console.log('Error syncing the table and model')
// }); 
