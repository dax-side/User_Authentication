// const Nuser = require('../models/user_auth')
const User = require('../models/user_auth')
exports.register = async (req, res, next) => {
    const { firstName, lastName, email, password, phone } = req.body

    // if (password.length < 6) {
    //     return res.status(400).json({ message: "Password less than 6 characters" })
    // }
    try {
        await User.create({
            firstName,
            lastName,
            email,
            password,
            phone,
        }).then(user =>
            res.status(200).json({
                message: "Registration Successful",
                user,
            })
            )
    } catch (err){
        res.status(401).json({
            message: "Registration Unsuccessful",
            error: err.message
        })
    }
}